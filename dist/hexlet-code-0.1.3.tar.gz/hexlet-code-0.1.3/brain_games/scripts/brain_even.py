#!/usr/bin/env python
from brain_games.game import start_game


def main():
    start_game()


if __name__ == '__main__':
    main()
