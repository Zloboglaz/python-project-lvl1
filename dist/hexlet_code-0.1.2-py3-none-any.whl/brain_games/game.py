import prompt


rules = 'Answer "yes" if the number is even, otherwise answer "no".'
wrong_answ = " is wrong answer ;(. Correct answer was "
right_answ = "Correct!"
try_again = "Let's try again, "


def start_game():
    print(rules)
    # name = prompt.string('May I have your name? ')
    # return 'Hello, {}!'.format(name)
